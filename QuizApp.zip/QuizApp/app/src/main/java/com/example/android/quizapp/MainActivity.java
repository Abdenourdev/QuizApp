package com.example.android.quizapp;

import androidx.appcompat.app.AppCompatActivity;


import android.annotation.SuppressLint;
import android.os.Bundle;
import android.text.Editable;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.text.BreakIterator;

public class MainActivity extends AppCompatActivity {
    int score =0;
    


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

        /**
         * scores Radio Group Two.
         */
    public void scoreRadioGroup(View view) {
        boolean checked = ((RadioButton) view).isChecked();
        switch (view.getId()) {
            case R.id.radio1:
                if (checked)
                    score = score + 1;
                break;
            case R.id.radio2:
                if (checked)
                    score += 0;
                break;
            case R.id.radio3:
                if (checked)
                    score += 0;
                break;
            case R.id.radio4:
                if (checked)
                    score += 0;
                break;
        }
    }
    public void scoreRadioGroupTwo(View view) {
        boolean checked = ((RadioButton) view).isChecked();
        switch (view.getId()) {
            case R.id.radio11:
                if (checked)
                    score = score + 1;
                break;
            case R.id.radio22:
                if (checked)
                    score += 0;
                break;
            case R.id.radio33:
                if (checked)
                    score += 0;
                break;
            case R.id.radio44:
                if (checked)
                    score += 0;
                break;
        }
    }




    public void addOnePointToScore(View view) {
        // Is the view now checked?
        boolean checked = ((CheckBox) view).isChecked();
        // Check which checkbox was clicked
        switch (view.getId()) {
            case R.id.checkbox1:
                if (checked)
                    score = score + 1;
                break;
            case R.id.checkbox2:
                if (checked)
                    score = score + 0;
                break;
            case R.id.checkbox3:
                if (checked)
                    score = score + 0;
                break;
            case R.id.checkbox4:
                if (checked)
                    score += 0;
                break;
        }
    }
    public void scoreRadioGroupThree(View view) {
        boolean checked = ((RadioButton) view).isChecked();
        switch (view.getId()) {
            case R.id.radio111:
                if (checked)
                    score = score + 1;
                break;
            case R.id.radio222:
                if (checked)
                    score += 0;
                break;
            case R.id.radio333:
                if (checked)
                    score += 0;
                break;
            case R.id.radio444:
                if (checked)
                    score += 0;
                break;
        }
    }

    /**
     * This method displays the given text on the screen.
     * @param view
     */
    public void displayMessage(View view) {
        EditText text = (EditText) findViewById(R.id.edit_text2);
        String simpleEditText = text.getText().toString();
        String name1 = simpleEditText.toString();
        if (name1.equalsIgnoreCase("1822")) {
            score = score+1;
            }else{
            score += 0;

        }
        EditText nameField = (EditText) findViewById(R.id.edit_text);
        Editable nameEditable = nameField.getText();
        String name = nameEditable.toString();
        String message = "Hi "+name;
        message +="\nYOUR score"+ score + "/5 points!";
        message+="\nTry again!";
        message+="\nThank you";
        Toast toast = Toast.makeText(this, message, Toast.LENGTH_LONG);
        toast.setGravity(Gravity.BOTTOM, 0, 0);
        toast.show();



    }


}



